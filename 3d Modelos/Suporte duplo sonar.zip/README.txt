2 ultrasonic sensor holders for SMARS by MarcDuGard on Thingiverse: https://www.thingiverse.com/thing:2952690

Summary:
For 2 ultrasonic sensors or others. 