HC-SR04 Board Triple Mount (30deg) by Ledimestari on Thingiverse: https://www.thingiverse.com/thing:2838662

Summary:
Triple mount for ultrasonic sensor.Same as https://www.thingiverse.com/thing:2838645 but with 30 deg sides. 