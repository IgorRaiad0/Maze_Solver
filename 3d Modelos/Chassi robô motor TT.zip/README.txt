modified smars for use with TT motors and a 4 AA battery pack by manauman on Thingiverse: https://www.thingiverse.com/thing:5154362

Summary:
This is a remix of the smars robot that allows use with the yellow, geared TT motors and a 4 AA battery pack 